/*
 * Group Assignment 1
 * Summer 2023
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * This program simulates the game Minesweeper by reading an input file and displaying
 * an output file solving the game with the correct ruling conventions.
 *
 * @author Eric Lottsfeldt
 * @version 7/2/2023
 */
public class MinesweeperMain {
	/**
	 * Main method for the Minesweeper program.
	 * 
	 * @param args The command line argument.
	 */
    public static void main (final String[] args) {
        try {
            final Scanner scanner = new Scanner (new File ("C:\\Users\\elott\\Downloads\\minesweeper_input.txt"));
            int fieldNumber = 1;

            while (scanner.hasNext()) {
                final char[][] field = readField (scanner);
                if (field == null) {
                    break;
                }
                System.out.println ("Field #" + fieldNumber + ":");
                final char[][] result = solveField (field);
                System.out.println (printField (result));
                fieldNumber++;
            }
            scanner.close();
        } catch (final FileNotFoundException e) {
            throw new IllegalArgumentException ("Input file not found.", e);
        }
    }
    /**
     * The solution is calculated through the count of adjacent mines in each cell.
     * 
     * @param field The configuration of the minefield.
     * @return The solved minefield with the correct count.
     */
    static char[][] readField (Scanner scanner) {
        final int row = scanner.nextInt();
        final int col = scanner.nextInt();
        if (row == 0 && col == 0) {
            return null;
        }
        final char[][] field = new char[row][col];
        for (int i = 0; i < row; i++) {
            final String rowData = scanner.next();
            if (rowData.length() != col) {
                throw new IllegalArgumentException ("Row length does not match specified dimensions.");
            }
            for (char cell : rowData.toCharArray()) {
                if(cell != '*' && cell != '.') {
                    throw new IllegalArgumentException ("Invalid cell character in input: " + cell);
                }
            }
            field[i] = rowData.toCharArray();
        }
        return field;
    }
    /**
     * Counts the number of adjacent mines for a specified cell.
     * 
     * @param field The configuration of the minefield.
     * @param row The row index.
     * @param col The column index.
     * @return The number of adjacent mines.
     */
    static int countAdjacentMines(final char[][] field, final int row, final int col) {
        int count = 0;
        final int n = field.length;
        final int m = field[0].length;
        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = col - 1; j <= col + 1; j++) {
                if (i >= 0 && i < n && j >= 0 && j < m && field[i][j] == '*') {
                    count++;
                }
            }
        }
        return count;
    }
    /**
     * This method solves the given field by counting the number 
     * of adjacent mines for each cell.
     * 
     * @param field The configuration of the minefield.
     * @return A 2D char array representing the solved field.
     */
    static char[][] solveField(final char[][] field) {
        final int row = field.length;
        final int col = field[0].length;
        final char[][] result = new char[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (field[i][j] == '*') {
                    result[i][j] = '*';
                } else {
                    final int count = countAdjacentMines (field, i, j);
                    result[i][j] = (char) ('0' + count);
                }
            }
        }
        return result;
    }
    /**
     * Prints the solution to the console.
     * 
     * @param field The configuration of the minefield.
     */
    static String printField (final char[][] field) {
        StringBuilder sb = new StringBuilder();
        for (final char[] row : field) {
            sb.append (row).append ('\n');
        }
        return sb.toString();
    }
}