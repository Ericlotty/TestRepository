import org.junit.jupiter.api.Test;
import java.util.Scanner;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class MinesweeperTest {

    @Test
    public void testSolveField() {
    	char[][] field = {
                {'.', '*', '.'},
                {'*', '.', '*'},
                {'.', '*', '.'}
            };

            char[][] expected = {
                {'2', '*', '2'},
                {'*', '4', '*'},
                {'2', '*', '2'}
            };

            assertArrayEquals(expected, MinesweeperMain.solveField(field));
        }

    @Test
    public void testCountAdjacentMines() {
    	char[][] field = {
                {'.', '*', '.'},
                {'*', '.', '*'},
                {'.', '*', '.'}
            };

            assertEquals(2, MinesweeperMain.countAdjacentMines(field, 0, 0));
            assertEquals(4, MinesweeperMain.countAdjacentMines(field, 1, 1));
            assertEquals(2, MinesweeperMain.countAdjacentMines(field, 2, 2));
        }

    @Test
    public void testPrintField() {
    	char[][] field = {
                {'2', '*', '2'},
                {'*', '4', '*'},
                {'2', '*', '2'}
            };

            String expected = "2*2\n*4*\n2*2\n";
            assertEquals(expected, MinesweeperMain.printField(field));
        }
    @Test
    public void testReadField_validInput() {
    	String input = "3 3\n" +
                "..*\n" +
                "*.*\n" +
                "..*\n" +
                "0 0\n";
    	Scanner scanner = new Scanner(input);
    	char[][] expected = {
    			{'.', '.', '*'},
    			{'*', '.', '*'},
    			{'.', '.', '*'}
    	};
    	assertArrayEquals(expected, MinesweeperMain.readField(scanner));
    }
    @Test
    public void testReadField_invalidDimensions() {
    	String input = "2 3\n" +
                "..*\n" +
                "*.*.\n" + // Invalid length
                "0 0\n";
    	Scanner scanner = new Scanner(input);
    	assertThrows(IllegalArgumentException.class, () -> MinesweeperMain.readField(scanner));
    }
    @Test
    public void testReadField_invalidCharacter() {
    	String input = "2 3\n" +
                "..*\n" +
                "*x*\n" + // Invalid character 'x'
                "0 0\n";
    	Scanner scanner = new Scanner(input);
    	assertThrows(IllegalArgumentException.class, () -> MinesweeperMain.readField(scanner));
    }
}